from flask import Flask, session, redirect, request, url_for
from flask import render_template
import mysql.connector
from mysql.connector import connect, Error
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms import StringField
from wtforms.validators import DataRequired
import bcrypt


app = Flask(__name__, template_folder='templates')
app.config['SECRET_KEY'] = 'C2HWGVoMGfNTBsrYQg8EcMrdTimkZfAb'



@app.route('/index')
def index():
    if 'pseudo' in session:
        pseudo = session['pseudo']
        return render_template('index.html', pseudo=pseudo)
    else:
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database='agence_tourisme'
        )
        mycursor = mydb.cursor(buffered=True)
        query11 = "SELECT * FROM `circuit`"
        mycursor.execute(query11)
        ttii = mycursor.fetchall()
        return render_template('index.html', your_list=ttii)


@app.route('/lieu/<lieu>')
def lieu(lieu):
    mydb = mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database='agence_tourisme'
    )
    mycursor = mydb.cursor(buffered=True)
    query = "SELECT url FROM `image` JOIN lieu ON id_lieu = lieu.id WHERE lieu.label = '%s' " % lieu
    mycursor.execute(query)
    for url in mycursor:
        url_lieu = str(url)[2:-3]
    query2 = "SELECT nom FROM ville JOIN lieu ON ville.id = id_ville WHERE lieu.label = '%s' " % lieu
    mycursor.execute(query2)
    for nom in mycursor:
        ville_lieu = str(nom)[2:-3]
    query3 = "SELECT pays.nom FROM pays JOIN ville ON pays.id = id_pays WHERE ville.nom = '%s' " % nom
    mycursor.execute(query3)
    for pays in mycursor:
        pays_lieu = str(pays)[2:-3]
    query4 = "SELECT description FROM lieu WHERE lieu.label = '%s' " % lieu
    mycursor.execute(query4)
    for description in mycursor:
        description_lieu = str(description)[2:-3]
    query5 = "SELECT prix_visite FROM lieu WHERE lieu.label = '%s' " % lieu
    mycursor.execute(query5)
    for prix in mycursor:
        prix_lieu = str(prix)[2:-3]
    nom_lieu = lieu
    return render_template('lieu.html', url=url_lieu, nom_lieu=nom_lieu, ville_lieu=ville_lieu, pays_lieu=pays_lieu,
                           description_lieu=description_lieu, prix_lieu=prix_lieu)

@app.route('/creercompte', methods=['GET', 'POST'])
def creercompte():
    class testform(FlaskForm):
        user = StringField('user', validators=[DataRequired()])
        mail = StringField('mail', validators=[DataRequired()])
        mdp = StringField('mdp', validators=[DataRequired()])
        nom = StringField('nom', validators=[DataRequired()])
        prenom = StringField('prenom', validators=[DataRequired()])
    form = testform()
    if form.validate_on_submit():
        user = request.form['user']
        mail = request.form['mail']
        mdp = request.form['mdp']
        nom = request.form['nom']
        prenom = request.form['prenom']
        sel = bcrypt.gensalt()
        mdp = mdp.encode(encoding = 'UTF-8', errors = 'strict')
        mdpcrypter = bcrypt.hashpw(mdp, sel)
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database='agence_tourisme'
        )
        mycursor = mydb.cursor()
        query5 = "INSERT INTO utilisateur (role_admin, nom, prenom, login, email, mdp) VALUES " \
                 "(%s, %s, %s, %s, %s, %s) "
        mycursor.execute(query5, (0, nom, prenom, user, mail, mdpcrypter))
        mydb.commit()
        return redirect(url_for('index'))

    return render_template('/creercompte.html', form=form)

@app.route('/connexion', methods=['GET', 'POST'])
def connexion():
    class connexionform(FlaskForm):
        user = StringField('user', validators=[DataRequired()])
        mdp = StringField('mdp', validators=[DataRequired()])
    form = connexionform()
    if form.validate_on_submit():
        user = request.form['user']
        mdpform = request.form['mdp']
        mydb = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database='agence_tourisme'
        )
        mycursor = mydb.cursor(buffered=True)
        query6 = "SELECT mdp FROM utilisateur WHERE login = '%s' " % user
        mycursor.execute(query6)
        md = (mycursor.fetchone()[0])
        mdpform = mdpform.encode('utf-8')
        md = md.encode('utf-8')
        if bcrypt.checkpw(mdpform, md):
            query7 = "SELECT login, nom, prenom, email, role_admin FROM utilisateur WHERE login = '%s' " % user
            mycursor.execute(query7)
            tti = mycursor.fetchall()
            for row in tti:
                p = row[0]
                n = row[1]
                pr = row[2]
                m = row[3]
                r = row[4]
            session['pseudo'] = p
            session['nom'] = n
            session['prenom'] = pr
            session['email'] = m
            session['role'] = r
            return redirect(url_for('index'))
        else:
            return redirect(url_for('connexion'))

    return render_template('/connexion.html', form=form)



if __name__ == '__main__':
    app.run(debug=True)